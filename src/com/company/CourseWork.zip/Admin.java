package com.company;

public class Admin extends User{
    public Admin(String name, String login, String password) {
        super(name, login, password);
    }
}
